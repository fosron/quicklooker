print("hello")
let x = 42
